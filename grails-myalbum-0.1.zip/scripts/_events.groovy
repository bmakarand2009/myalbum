
eventPackagePluginStart = {pluginName ->
    pluginExcludes << "web-app/js/"
    pluginExcludes << "web-app/css/"
    pluginExcludes << "web-app/images/"
    pluginExcludes << "grails-app/views/layouts/"

   
}


